package com.bks.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bks.configuration.SupplierRepository;
import com.bks.model.Supplier;

public class SupplierController {

	@Autowired
	SupplierRepository supplierRepo; 
	
	@GetMapping("/a/supplier")
	public String getAdminCustomer(Model model) {
		model.addAttribute("supplier", supplierRepo.findAll());
		return "admin/supplier";
	}
	
	@RequestMapping("/g/supplier")
	public String getUserChalani(Model uModel) {
		uModel.addAttribute("gCustomer", supplierRepo.findAll());
		return "/guest/supplier";
	}
	
	@RequestMapping("/a/addSupplier")
	public String addCustomer () {
		return "admin/addSupplier";
	}
	
	@RequestMapping(value ="/a/supplier/add", method = RequestMethod.POST)
	public String addUser (@Valid Supplier supplier) {
		
			supplierRepo.save(supplier);
		
		return "redirect:a/supplier";
	}
	
	@RequestMapping("a/customer/delete/{id}")
	@ResponseBody
	public String delete(@PathVariable("id") int id) {
		supplierRepo.deleteById(id);
		return "a/supplier";
	}

	@RequestMapping(value = "a/customer/modify/{id}", method = RequestMethod.POST)
	public String updateUser (@PathVariable("id") int id, @ModelAttribute Supplier supplier, Model model) {
		model.addAttribute("model", supplierRepo.findById(id));
		supplierRepo.save(supplier);
		return "redirect: a/customer"; 
	}
}
