package com.bks.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bks.configuration.ProductRepository;
import com.bks.model.Product;

public class ProductController {

	@Autowired
	ProductRepository productRepo;
	
	@GetMapping("/a/product")
	public String getAdminCustomer(Model model) {
		model.addAttribute("supplier", productRepo.findAll());
		return "admin/product";
	}
	
	@RequestMapping("/g/product")
	public String getUserChalani(Model uModel) {
		uModel.addAttribute("gCustomer", productRepo.findAll());
		return "/guest/product";
	}
	
	@RequestMapping("/a/addProduct")
	public String addCustomer () {
		return "admin/addPRoduct";
	}
	
	@RequestMapping(value ="/a/product/add", method = RequestMethod.POST)
	public String addUser (@Valid Product product) {
		
			productRepo.save(product);
		
		return "redirect:a/product";
	}
	
	@RequestMapping("a/customer/delete/{id}")
	@ResponseBody
	public String delete(@PathVariable("id") int id) {
		productRepo.deleteById(id);
		return "a/supplier";
	}

	@RequestMapping(value = "a/customer/modify/{id}", method = RequestMethod.POST)
	public String updateUser (@PathVariable("id") int id, @ModelAttribute Product product, Model model) {
		model.addAttribute("model", productRepo.findById(id));
		productRepo.save(product);
		return "redirect: a/product"; 
	}
}
