package com.bks.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MainController {
	
	@RequestMapping("/")
	public String main() {
		return "admin/dashboard";
	}
	
	@GetMapping("/loginPage")
	public String login() {
		return "login";
	}
	
	@RequestMapping("/admin/dashboard")
	public String adminDashboard() {
		return "admin/dashboard";
	}
	
	@RequestMapping("/user/dashboard")
	public String userDashboard() {
		return "user/dashboard";
	}	
}
