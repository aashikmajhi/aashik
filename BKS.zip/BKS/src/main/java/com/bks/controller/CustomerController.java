package com.bks.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bks.configuration.CustomerRepository;
import com.bks.model.Customer;


public class CustomerController {

	@Autowired
	CustomerRepository customerRepo; 
	
	@GetMapping("/a/customer")
	public String getAdminCustomer(Model model) {
		model.addAttribute("customer", customerRepo.findAll());
		return "admin/customer";
	}
	
	@RequestMapping("/g/customer")
	public String getUserChalani(Model uModel) {
		uModel.addAttribute("gCustomer", customerRepo.findAll());
		return "/guest/customer";
	}
	
	@RequestMapping("/a/addCustomer")
	public String addCustomer () {
		return "admin/addCustomer";
	}
	
	@RequestMapping(value ="/a/customer/add", method = RequestMethod.POST)
	public String addUser (@Valid Customer customer) {
		
			customerRepo.save(customer);
		
		return "redirect:a/customer";
	}
	
	@RequestMapping("a/customer/delete/{id}")
	@ResponseBody
	public String delete(@PathVariable("id") int id) {
		customerRepo.deleteById(id);
		return "a/customer";
	}

	@RequestMapping(value = "a/customer/modify/{id}", method = RequestMethod.POST)
	public String updateUser (@PathVariable("id") int id, @ModelAttribute Customer customer, Model model) {
		model.addAttribute("model", customerRepo.findById(id));
		customerRepo.save(customer);
		return "redirect: a/customer"; 
	}
}
