package com.bks.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bks.configuration.UserRepository;
import com.bks.model.Users;
import com.bks.services.UserServiceInterface;
import com.bks.validation.EmailExitsException;


public class UsersController {
	@Autowired
	private UserRepository userRepo;

	@Autowired
	private UserServiceInterface userService;

	@RequestMapping("/a/user")
	public String getAllUsers(Model model) {
		model.addAttribute("users", userRepo.findAll());
		return "admin/users";
	}
	
	@RequestMapping("/u/user")
	public String getUsers(Model model) {
		model.addAttribute("users", userRepo.findAll());
		return "user/users";
	}

	@RequestMapping("/a/user/addUser")
	public String addUser () {
		return "admin/addUser";
	}
	
	@RequestMapping(value ="/add", method = RequestMethod.POST)
	public String addUser (@Valid @ModelAttribute Users user, BindingResult result) {
		try {
			userService.RegisterNewUser(user);
		} catch (EmailExitsException e) {
			result.addError(new FieldError("user", "email", e.getMessage()));
			return "redirect:a/addUser";
		}
		return "redirect:a/user";
	}
	
	@RequestMapping("a/user/delete/{id}")
	@ResponseBody
	public String delete(@PathVariable("id") int id) {
		userRepo.deleteById(id);
		return "admin/user";
	}

	@RequestMapping("a/editUser/{id}")
	public String editUser(@PathVariable("id") int id, Model model) {
		model.addAttribute("users", userRepo.findById(id));
		return "admin/editUser";
	}
	
	
	@RequestMapping(value = "a/user/modify/{id}", method = RequestMethod.POST)
	public String updateUser (@PathVariable("id") int id, @ModelAttribute Users user, Model model) {
		model.addAttribute("model", userRepo.findById(id));
		userRepo.save(user);
		return "redirect:a/user"; 
	}
}
