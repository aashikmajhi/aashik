package com.bks.validation;

@SuppressWarnings("serial")
public class EmailExitsException extends Throwable {

	public EmailExitsException(final String message) {
		super(message);
	}
}
