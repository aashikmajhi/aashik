package com.bks.services;

import com.bks.model.Users;
import com.bks.validation.EmailExitsException;

public interface UserServiceInterface {

	Users RegisterNewUser(Users user) throws EmailExitsException;
}
