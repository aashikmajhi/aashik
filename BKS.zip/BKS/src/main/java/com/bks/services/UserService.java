package com.bks.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.bks.configuration.UserRepository;
import com.bks.model.Users;
import com.bks.validation.EmailExitsException;

public class UserService implements UserServiceInterface {

	@Autowired
	UserRepository userRepo;

	@Override
	public Users RegisterNewUser(Users user) throws EmailExitsException {
		// TODO Auto-generated method stub
		if(EmailExit(user.getEmail())) {
			throw new EmailExitsException("Email already Exits: "+ user.getEmail());
		}
		user.setPassword(new BCryptPasswordEncoder().encode(user.getPassword()));
		return userRepo.save(user);
	}

	private boolean EmailExit(String email) {
		// TODO Auto-generated method stub
		final Users users = userRepo.findbyEmail(email);
		return users != null;
	} 
	
}
