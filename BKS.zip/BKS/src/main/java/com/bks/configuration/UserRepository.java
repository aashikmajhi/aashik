package com.bks.configuration;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bks.model.Users;

public interface UserRepository extends JpaRepository<Users, Integer> {
	Users findbyEmail(String email);
}
