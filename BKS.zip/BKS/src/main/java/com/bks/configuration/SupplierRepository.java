package com.bks.configuration;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bks.model.Supplier;

public interface SupplierRepository extends JpaRepository<Supplier, Integer> {

}
