package com.bks.configuration;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bks.model.Product;

public interface ProductRepository extends JpaRepository<Product, Integer> {

}
